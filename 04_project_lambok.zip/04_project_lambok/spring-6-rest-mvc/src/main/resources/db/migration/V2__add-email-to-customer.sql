alter table customer
add column email varchar(255);